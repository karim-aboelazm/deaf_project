export const BAZEL_PACKAGES = new Set([
  'tfjs-core',
  'tfjs-backend-cpu',
  'tfjs-tfdf',
  'tfjs-tflite',
  'tfjs-converter',
  'tfjs-backend-webgl',
  'tfjs-backend-webgpu',
  'tfjs-layers',
  'tfjs-data',
  'tfjs-backend-wasm',
]);
